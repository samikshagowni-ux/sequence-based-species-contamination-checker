# Sequence-Based Species Contamination Checker

A beginner-friendly Streamlit application for an educational metagenomics project. It compares sample DNA reads against a user-provided reference FASTA database using the specified simple, ungapped, same-length-window identity method.

> **Scientific caution:** This is an educational prototype. A sequence match is not proof of contamination. Do not use it for clinical, diagnostic, food-safety, or environmental decisions.

## Features

- Upload sample reads and reference sequences in FASTA format.
- Validate DNA characters (`A`, `C`, `G`, `T`, `N`).
- Compare forward and reverse-complement reads against every same-length reference window.
- Configure the minimum identity threshold (50–100%; default 90%).
- Classify reads as Species Match, Ambiguous, or Unclassified.
- Summarise counts and proportions, chart results, flag unexpected matches, and download CSV reports.
- Load a clearly labelled synthetic demo dataset.
- Unit tests for core algorithm behaviour.

FASTQ is not supported in this version.

## Project structure

```text
species-contamination-checker/
├── app.py
├── main.py
├── requirements.txt
├── README.md
├── data/
│   ├── sample_reads.fasta
│   └── reference_sequences.fasta
├── tests/
│   └── test_main.py
└── utils/
    └── sequence_analysis.py
```

## Run locally (VS Code or terminal)

1. Install Python 3.10 or newer.
2. Download and unzip this project.
3. Open the extracted `species-contamination-checker` folder in VS Code.
4. Open a terminal in that folder.
5. Create a virtual environment:

   **macOS/Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

   **Windows**
   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```

6. Install dependencies:
   ```bash
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```
7. Start the website:
   ```bash
   streamlit run app.py
   ```
8. Streamlit prints a local URL (usually `http://localhost:8501`). Open it in your browser.

## First-time demo

1. In the sidebar, select **Home & Analyse**.
2. Click **Load Demo Dataset**.
3. Keep the default identity threshold of 90%.
4. Click **Analyse Sequences**.
5. Select **Results** in the sidebar to view charts, warnings, detailed results and CSV downloads.

The demo sequences are synthetic and are not biological reference data.

## FASTA input format

Sample reads can use any FASTA record IDs:

```fasta
>read_001
ACGTACGTACGT
```

Reference headers must begin with the species name. The part before the first `|` is used as the species name:

```fasta
>Escherichia_coli|reference_1
ACGTACGTACGTACGT
```

Underscores in species names are displayed as spaces. The only accepted sequence characters are `A`, `C`, `G`, `T`, and `N`.

## How classification works

For each read, the program:

1. Checks every same-length window in every reference sequence.
2. Checks both the read and its reverse complement.
3. Calculates identity as matching positions divided by compared positions, multiplied by 100.
4. Keeps the highest score and the species associated with it.
5. Applies the selected threshold:
   - Below threshold: **Unclassified**.
   - At or above threshold, one best species: **Species Match**.
   - At or above threshold, multiple tied best species: **Ambiguous**.

If multiple reference records from the same species tie, that is still a single species-level match. Reads longer than a reference are skipped for that reference. If no reference can accommodate a read, it is unclassified with a 0% score.

This is an ungapped educational matching method. It does not perform local/global alignment, account for insertions/deletions, or infer organism abundance.

## Run tests

From the project folder, with the environment activated:

```bash
pytest -q
```

## Optional command-line run

The same analysis engine can be run without the Streamlit interface:

```bash
python main.py --reads data/sample_reads.fasta --references data/reference_sequences.fasta --threshold 90 --output results.csv
```

## Upload to GitHub

1. Create or sign in to a GitHub account.
2. Create a new repository, for example `species-contamination-checker`.
3. In the project folder, initialise Git and commit the files:

   ```bash
   git init
   git add .
   git commit -m "Build sequence contamination checker"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/species-contamination-checker.git
   git push -u origin main
   ```

4. Replace `YOUR-USERNAME` with your GitHub username. Do not upload private or sensitive sequence data.

If Git asks for authentication, sign in through the browser prompt or use GitHub's recommended authentication method.

## Deploy online

### Streamlit Community Cloud

1. Push the project to GitHub using the steps above.
2. Sign in to Streamlit Community Cloud with GitHub.
3. Choose **Create app** and select your repository, branch (`main`) and `app.py`.
4. Deploy. Streamlit installs packages from `requirements.txt`.
5. Open the generated app URL.

### Replit

1. Create a Python Repl and import the GitHub repository.
2. In the Shell, run `pip install -r requirements.txt`.
3. Set the run command to `streamlit run app.py --server.address 0.0.0.0 --server.port 3000`.
4. Use Replit's web preview.

### GitHub Codespaces

1. Open the repository on GitHub.
2. Select **Code → Codespaces → Create codespace**.
3. In the terminal, run `pip install -r requirements.txt`.
4. Run `streamlit run app.py --server.address 0.0.0.0`.
5. Open the forwarded port 8501 when Codespaces offers it.

### Visual Studio Code

Follow the local setup instructions above. VS Code is the editor; the app runs in the terminal and browser.

## Troubleshooting

- `streamlit: command not found`: activate the virtual environment and run `python -m pip install -r requirements.txt`.
- Missing module: make sure the terminal is in the project root and install requirements again.
- No records found: check that each FASTA record starts with `>` on its own line.
- Invalid character error: remove characters other than `A`, `C`, `G`, `T`, and `N` from sequence lines.
- App does not appear: check the terminal for the local URL and any error message.
