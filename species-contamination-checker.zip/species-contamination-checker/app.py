from pathlib import Path
import pandas as pd
import plotly.express as px
import streamlit as st

from utils.sequence_analysis import (
    FastaValidationError, parse_fasta, classify_reads, build_summary, make_summary_csv
)

st.set_page_config(
    page_title="Sequence-Based Species Contamination Checker",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
.stApp { background: #f4f7fa; }
section[data-testid="stSidebar"] { background: #10243a; }
section[data-testid="stSidebar"] * { color: #f5fbff !important; }
.hero { padding: 1.5rem 1.7rem; border-radius: 16px; color: white;
        background: linear-gradient(115deg,#10243a,#0d6670); margin-bottom: 1rem; }
.hero h1 { color: white; margin-bottom: .25rem; }
.metric-card { background: white; border: 1px solid #dce6ed; border-radius: 13px;
               padding: 1rem 1.1rem; min-height: 105px; }
.metric-label { color: #526577; font-size: .88rem; }
.metric-value { color: #10243a; font-size: 1.8rem; font-weight: 700; }
.small-note { color: #526577; font-size: .88rem; }
</style>
""", unsafe_allow_html=True)

st.sidebar.markdown("## 🧬 SequenceCheck")
page = st.sidebar.radio("Navigation", ["Home & Analyse", "Results", "About & Limitations"])
threshold = st.sidebar.slider(
    "Minimum sequence identity (%)", min_value=50, max_value=100, value=90, step=1
)
st.sidebar.caption(
    "A read is assigned only when its best identity meets this threshold. "
    "Higher thresholds are more stringent."
)

st.markdown("""
<div class="hero">
  <h1>🧬 Sequence-Based Species Contamination Checker</h1>
  <p>Explore species-level sequence matches in synthetic or user-provided metagenomic DNA reads.</p>
</div>
""", unsafe_allow_html=True)

def load_demo_text():
    data_dir = Path(__file__).parent / "data"
    return (
        (data_dir / "sample_reads.fasta").read_text(),
        (data_dir / "reference_sequences.fasta").read_text()
    )

if page == "Home & Analyse":
    st.subheader("Upload DNA sequence files")
    st.write("Upload a sample-read FASTA file and a reference FASTA file. Reference headers must begin with the species name, followed by `|`.")
    col1, col2 = st.columns(2)
    with col1:
        sample_upload = st.file_uploader("A. Sample Reads FASTA", type=["fa", "fasta", "fna"], key="sample")
    with col2:
        reference_upload = st.file_uploader("B. Reference Sequences FASTA", type=["fa", "fasta", "fna"], key="reference")

    demo_col, info_col = st.columns([1, 2])
    with demo_col:
        if st.button("Load Demo Dataset", use_container_width=True):
            sample_text, reference_text = load_demo_text()
            st.session_state["sample_text"] = sample_text
            st.session_state["reference_text"] = reference_text
            st.session_state["demo_loaded"] = True
            st.success("Synthetic demonstration dataset loaded.")
    with info_col:
        st.info("Demo files are synthetic examples designed to demonstrate species matches, ambiguity and unclassified reads.")

    sample_text = st.session_state.get("sample_text")
    reference_text = st.session_state.get("reference_text")
    if sample_upload is not None:
        sample_text = sample_upload.getvalue().decode("utf-8", errors="replace")
    if reference_upload is not None:
        reference_text = reference_upload.getvalue().decode("utf-8", errors="replace")

    st.subheader("Optional expected species")
    expected_input = st.text_input(
        "Expected species (comma-separated; optional)",
        placeholder="Escherichia coli, Bacillus subtilis"
    )
    expected_species = {item.strip().casefold() for item in expected_input.split(",") if item.strip()}

    st.caption("Accepted DNA characters: A, C, G, T and N. FASTQ is not supported in this version.")
    if st.button("Analyse Sequences", type="primary", use_container_width=True):
        if not sample_text or not reference_text:
            st.error("Please provide both the sample reads FASTA and reference FASTA files.")
        else:
            try:
                samples = parse_fasta(sample_text)
                references = parse_fasta(reference_text, reference=True)
                progress = st.progress(0, text="Preparing sequence analysis...")
                def update_progress(done, total):
                    progress.progress(done / total, text=f"Analysing read {done} of {total}...")
                results = classify_reads(samples, references, threshold, update_progress)
                summary_table, stats = build_summary(results, len(references), threshold)
                st.session_state["results"] = results
                st.session_state["summary_table"] = summary_table
                st.session_state["stats"] = stats
                st.session_state["expected_species"] = expected_species
                st.session_state["references"] = references
                st.session_state["threshold"] = threshold
                st.session_state["demo_loaded"] = False
                progress.empty()
                st.success("Analysis completed. Open the Results page in the sidebar.")
            except (FastaValidationError, ValueError) as exc:
                st.error(str(exc))
            except Exception as exc:
                st.error(f"An unexpected error occurred: {exc}")

    st.markdown("---")
    st.subheader("How it works")
    st.write("Each read is compared with every same-length window in each reference sequence, in both forward and reverse-complement orientations. The best ungapped identity score is used for classification.")

elif page == "Results":
    if "results" not in st.session_state:
        st.info("No analysis results yet. Go to **Home & Analyse**, upload files or load the synthetic demo dataset, and click Analyse Sequences.")
    else:
        results = st.session_state["results"]
        summary = st.session_state["summary_table"]
        stats = st.session_state["stats"]
        expected = st.session_state.get("expected_species", set())

        st.subheader("Analysis overview")
        metric_cols = st.columns(5)
        metric_items = [
            ("Total reads", stats["total_reads"]),
            ("Reference sequences", stats["reference_sequences"]),
            ("Species detected", stats["detected_species"]),
            ("Unclassified", stats["unclassified_reads"]),
            ("Ambiguous", stats["ambiguous_reads"]),
        ]
        for col, (label, value) in zip(metric_cols, metric_items):
            with col:
                st.markdown(
                    f'<div class="metric-card"><div class="metric-label">{label}</div>'
                    f'<div class="metric-value">{value}</div></div>',
                    unsafe_allow_html=True
                )

        st.markdown("---")
        left, right = st.columns(2)
        with left:
            st.subheader("Reads assigned to each group")
            if not summary.empty:
                chart = px.bar(summary, x="Detected Group", y="Read Count",
                               color="Detected Group", title=None)
                chart.update_layout(showlegend=False, xaxis_title="", yaxis_title="Read count")
                st.plotly_chart(chart, use_container_width=True)
        with right:
            st.subheader("Proportion of analysed reads")
            if not summary.empty:
                chart = px.pie(summary, names="Detected Group", values="Read Count", hole=0.48)
                st.plotly_chart(chart, use_container_width=True)

        st.subheader("Species and classification summary")
        st.dataframe(summary, use_container_width=True, hide_index=True)

        matched_species = set(
            results.loc[results["Classification Status"] == "Species Match", "Assigned Species"]
        )
        unexpected = sorted(
            species for species in matched_species
            if expected and species.casefold() not in expected
        )
        st.subheader("Warnings and uncertainty")
        if unexpected:
            st.warning("Unexpected species matches (not in the expected-species list): " + ", ".join(unexpected) +
                       ". These are flags for investigation, not confirmed contaminants.")
        elif expected:
            st.success("No detected species fell outside the expected-species list.")
        else:
            st.info("No expected-species list was supplied. Unexpected-species screening was not performed.")
        if stats["ambiguous_reads"]:
            st.warning(f"{stats['ambiguous_reads']} read(s) had tied best matches across multiple species.")
        if stats["unclassified_reads"]:
            st.warning(f"{stats['unclassified_reads']} read(s) did not meet the selected identity threshold.")
        st.caption("A sequence match or unexpected match is not proof of contamination.")

        st.subheader("Detailed read results")
        species_options = ["All"] + sorted(results["Assigned Species"].unique().tolist())
        status_options = ["All"] + sorted(results["Classification Status"].unique().tolist())
        filter1, filter2 = st.columns(2)
        with filter1:
            species_filter = st.selectbox("Filter by assigned group", species_options)
        with filter2:
            status_filter = st.selectbox("Filter by classification status", status_options)
        filtered = results.copy()
        if species_filter != "All":
            filtered = filtered[filtered["Assigned Species"] == species_filter]
        if status_filter != "All":
            filtered = filtered[filtered["Classification Status"] == status_filter]
        st.dataframe(filtered, use_container_width=True, hide_index=True)

        st.subheader("Download reports")
        c1, c2 = st.columns(2)
        with c1:
            st.download_button(
                "Download detailed results (CSV)",
                data=results.to_csv(index=False).encode("utf-8"),
                file_name="sequence_classification_results.csv",
                mime="text/csv",
                use_container_width=True,
            )
        with c2:
            st.download_button(
                "Download summary report (CSV)",
                data=make_summary_csv(summary, stats),
                file_name="sequence_analysis_summary.csv",
                mime="text/csv",
                use_container_width=True,
            )
        st.caption(f"Identity threshold used: {stats['threshold']:.0f}%")

else:
    st.subheader("About this project")
    st.write("This educational prototype compares DNA reads with a user-supplied reference FASTA database and summarises the best species-level matches.")
    st.subheader("Scientific limitations")
    st.markdown("""
    - This is an educational prototype, not a validated biological analysis pipeline.
    - The matching algorithm uses simple ungapped sequence identity over same-length windows.
    - It is not a full biological sequence-alignment method and does not model insertions or deletions.
    - Closely related species can have similar DNA sequences.
    - Identification quality depends on the completeness and correctness of the reference database.
    - A sequence match does not prove contamination.
    - Read proportions are not automatically equivalent to actual organism abundance.
    - Reliable biological conclusions require curated reference sequences and validated methods.
    - Do not use this application for clinical, diagnostic, food-safety or environmental decisions.
    """)
    st.subheader("Possible future improvements")
    st.write("Established tools such as BLAST and Kraken2 could be explored for more advanced sequence comparison and taxonomic classification.")
