"""Optional command-line entry point for the sequence analysis engine."""
import argparse
from pathlib import Path

from utils.sequence_analysis import parse_fasta, classify_reads, build_summary


def main():
    parser = argparse.ArgumentParser(description="Classify sample FASTA reads against reference FASTA sequences.")
    parser.add_argument("--reads", required=True, help="Path to sample reads FASTA")
    parser.add_argument("--references", required=True, help="Path to reference FASTA")
    parser.add_argument("--threshold", type=float, default=90.0, help="Minimum identity percentage (50-100)")
    parser.add_argument("--output", default="sequence_results.csv", help="Output detailed CSV path")
    args = parser.parse_args()

    samples = parse_fasta(Path(args.reads).read_text())
    references = parse_fasta(Path(args.references).read_text(), reference=True)
    results = classify_reads(samples, references, args.threshold)
    summary, stats = build_summary(results, len(references), args.threshold)
    results.to_csv(args.output, index=False)
    print(results.to_string(index=False))
    print("\nSummary:")
    print(summary.to_string(index=False))
    print(stats)


if __name__ == "__main__":
    main()
