from Bio.Seq import Seq
import pytest

from utils.sequence_analysis import (
    FastaValidationError, parse_fasta, best_window_identity, classify_reads
)


def test_exact_match():
    refs = parse_fasta(">Species_A|r1\nAACCGGTT\n", reference=True)
    reads = parse_fasta(">read1\nCCGG\n")
    result = classify_reads(reads, refs, 100)
    assert result.loc[0, "Classification Status"] == "Species Match"
    assert result.loc[0, "Assigned Species"] == "Species A"
    assert result.loc[0, "Best Identity Percentage"] == 100.0


def test_partial_match():
    refs = parse_fasta(">Species_A|r1\nAACCGGTT\n", reference=True)
    reads = parse_fasta(">read1\nCCGA\n")
    assert best_window_identity(reads[0]["sequence"], refs[0]["sequence"]) == 75.0
    result = classify_reads(reads, refs, 70)
    assert result.loc[0, "Classification Status"] == "Species Match"


def test_reverse_complement_match():
    reference = "AACCGGTT"
    read = str(Seq("CCGG").reverse_complement())
    refs = parse_fasta(f">Species_A|r1\n{reference}\n", reference=True)
    reads = parse_fasta(f">read1\n{read}\n")
    result = classify_reads(reads, refs, 100)
    assert result.loc[0, "Best Identity Percentage"] == 100.0


def test_low_identity_unclassified():
    refs = parse_fasta(">Species_A|r1\nAAAAAAAA\n", reference=True)
    reads = parse_fasta(">read1\nCCCC\n")
    result = classify_reads(reads, refs, 90)
    assert result.loc[0, "Classification Status"] == "Unclassified"


def test_tied_species_are_ambiguous():
    refs = parse_fasta(">Species_A|r1\nAACCGGTT\n>Species_B|r2\nAACCGGTT\n", reference=True)
    reads = parse_fasta(">read1\nCCGG\n")
    result = classify_reads(reads, refs, 100)
    assert result.loc[0, "Classification Status"] == "Ambiguous"


def test_same_species_reference_tie_is_not_ambiguous():
    refs = parse_fasta(">Species_A|r1\nAACCGGTT\n>Species_A|r2\nAACCGGTT\n", reference=True)
    reads = parse_fasta(">read1\nCCGG\n")
    result = classify_reads(reads, refs, 100)
    assert result.loc[0, "Classification Status"] == "Species Match"


def test_invalid_dna_character():
    with pytest.raises(FastaValidationError, match="invalid DNA"):
        parse_fasta(">read1\nACGTX\n")


def test_empty_fasta():
    with pytest.raises(FastaValidationError, match="empty"):
        parse_fasta("")


def test_empty_sequence_record():
    with pytest.raises(FastaValidationError, match="empty sequence"):
        parse_fasta(">read1\n")


def test_read_longer_than_reference_is_unclassified():
    refs = parse_fasta(">Species_A|r1\nACGT\n", reference=True)
    reads = parse_fasta(">read1\nACGTACGT\n")
    result = classify_reads(reads, refs, 50)
    assert result.loc[0, "Classification Status"] == "Unclassified"
