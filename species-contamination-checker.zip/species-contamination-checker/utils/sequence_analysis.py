"""Simple ungapped, same-length-window DNA read matching for an educational project."""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from io import StringIO
from typing import Callable, Iterable

import pandas as pd
from Bio import SeqIO
from Bio.Seq import Seq

VALID_DNA = set("ACGTN")


class FastaValidationError(ValueError):
    """Raised when a FASTA file is empty or contains invalid DNA records."""


def parse_fasta(source: str, *, reference: bool = False) -> list[dict[str, str]]:
    """Parse FASTA text and validate records. Reference headers use name|accession."""
    if not isinstance(source, str) or not source.strip():
        raise FastaValidationError("The FASTA file is empty.")

    try:
        records = list(SeqIO.parse(StringIO(source), "fasta"))
    except Exception as exc:
        raise FastaValidationError(f"Could not parse FASTA: {exc}") from exc

    if not records:
        raise FastaValidationError(
            "No FASTA records were found. Each record must start with a '>' header."
        )

    parsed = []
    for index, record in enumerate(records, start=1):
        sequence = str(record.seq).upper().replace(" ", "").replace("\n", "")
        record_id = record.id or f"record_{index}"
        if not sequence:
            raise FastaValidationError(f"Record '{record_id}' has an empty sequence.")
        invalid = sorted(set(sequence) - VALID_DNA)
        if invalid:
            raise FastaValidationError(
                f"Record '{record_id}' contains invalid DNA character(s): "
                + ", ".join(invalid)
                + ". Allowed characters are A, C, G, T and N."
            )

        species = None
        if reference:
            header = record.description
            species_token = header.split("|", 1)[0].strip()
            if not species_token:
                raise FastaValidationError(
                    f"Reference record '{record_id}' must start with a species name."
                )
            species = species_token.replace("_", " ")

        parsed.append({
            "id": record_id,
            "sequence": sequence,
            "species": species,
        })
    return parsed


def best_window_identity(read: str, reference: str) -> float | None:
    """Return the best identity against all same-length windows, or None if too long."""
    read = read.upper()
    reference = reference.upper()
    width = len(read)
    if width == 0 or width > len(reference):
        return None

    best_matches = -1
    for start in range(len(reference) - width + 1):
        window = reference[start:start + width]
        matches = sum(a == b for a, b in zip(read, window))
        if matches > best_matches:
            best_matches = matches
            if best_matches == width:
                break
    return (best_matches / width) * 100.0


def classify_reads(
    sample_records: list[dict[str, str]],
    reference_records: list[dict[str, str]],
    threshold: float = 90.0,
    progress_callback: Callable[[int, int], None] | None = None,
) -> pd.DataFrame:
    """Classify each read using forward and reverse-complement window identity.

    Ties are resolved by species, not by reference record: two tied references
    from the same species still represent one species-level best hit.
    """
    if not 50 <= float(threshold) <= 100:
        raise ValueError("Identity threshold must be between 50 and 100.")
    if not sample_records:
        raise ValueError("No sample reads were supplied.")
    if not reference_records:
        raise ValueError("No reference sequences were supplied.")

    rows = []
    total = len(sample_records)
    for read_index, read_record in enumerate(sample_records, start=1):
        read = read_record["sequence"].upper()
        reverse = str(Seq(read).reverse_complement())
        best_score = -1.0
        best_species: set[str] = set()

        for reference in reference_records:
            score_forward = best_window_identity(read, reference["sequence"])
            score_reverse = best_window_identity(reverse, reference["sequence"])
            scores = [score for score in (score_forward, score_reverse) if score is not None]
            if not scores:
                continue
            score = max(scores)
            species = reference["species"]
            if score > best_score:
                best_score = score
                best_species = {species}
            elif score == best_score:
                best_species.add(species)

        if best_score < 0:
            best_score = 0.0

        if best_score < threshold:
            assigned = "Unclassified"
            status = "Unclassified"
        elif len(best_species) > 1:
            assigned = "Ambiguous"
            status = "Ambiguous"
        elif len(best_species) == 1:
            assigned = next(iter(best_species))
            status = "Species Match"
        else:
            assigned = "Unclassified"
            status = "Unclassified"

        rows.append({
            "Read ID": read_record["id"],
            "Assigned Species": assigned,
            "Best Identity Percentage": round(best_score, 2),
            "Classification Status": status,
        })
        if progress_callback:
            progress_callback(read_index, total)

    return pd.DataFrame(rows)


def build_summary(results: pd.DataFrame, reference_count: int, threshold: float) -> tuple[pd.DataFrame, dict]:
    """Build group counts and project-level summary statistics."""
    total = len(results)
    counts = Counter(results["Assigned Species"].tolist())
    summary_rows = []
    for group, count in counts.most_common():
        summary_rows.append({
            "Detected Group": group,
            "Read Count": count,
            "Proportion (%)": round((count / total * 100) if total else 0.0, 2),
        })
    summary_table = pd.DataFrame(
        summary_rows, columns=["Detected Group", "Read Count", "Proportion (%)"]
    )
    detected_species = results.loc[
        results["Classification Status"] == "Species Match", "Assigned Species"
    ].nunique()
    stats = {
        "total_reads": total,
        "reference_sequences": reference_count,
        "detected_species": int(detected_species),
        "unclassified_reads": int((results["Classification Status"] == "Unclassified").sum()),
        "ambiguous_reads": int((results["Classification Status"] == "Ambiguous").sum()),
        "threshold": float(threshold),
    }
    return summary_table, stats


def make_summary_csv(summary_table: pd.DataFrame, stats: dict) -> bytes:
    """Create a concise summary CSV with metadata followed by group counts."""
    metadata = [
        ["Metric", "Value"],
        ["Total reads analysed", stats["total_reads"]],
        ["Reference sequences", stats["reference_sequences"]],
        ["Species detected", stats["detected_species"]],
        ["Unclassified reads", stats["unclassified_reads"]],
        ["Ambiguous reads", stats["ambiguous_reads"]],
        ["Selected identity threshold (%)", stats["threshold"]],
        [],
        ["Detected Group", "Read Count", "Proportion (%)"],
    ]
    lines = [",".join(map(str, row)) for row in metadata]
    if not summary_table.empty:
        lines.extend(summary_table.to_csv(index=False, header=False).strip().splitlines())
    return ("\n".join(lines) + "\n").encode("utf-8")
